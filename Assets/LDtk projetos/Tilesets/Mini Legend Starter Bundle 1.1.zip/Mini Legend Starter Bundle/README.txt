
--------MESSAGE FROM ME-------------

Hi!

Thanks for downloading this asset pack!

Read GUIDES.txt for info about this pack.




--------CONTACT ME-------------

Don't hesitate to reach out or ask questions :)
Email: amonsteahotpot@gmail.com
Itch.io: https://alwaysrice.itch.io/mini-legend





--------FUTURE DEVELOPMENT-------------

I plan to design even more biomes, enemies, and refine the style further...

But I need your help ;)

If you are pleased with this project, 

Consider buying the paid packs!

They're dirt cheap.

Or best, donate :> 

But I can't ask for the impossible right?

Don't forget to drop a rating! 

It would help me soo much!







